function goToBiography()  {
    window.location.assign("biography.html")
}

function goToAchievements()  {
        window.location.assign("achievements.html")
}

function goToHome()  {
        window.location.assign("home.html")
}

